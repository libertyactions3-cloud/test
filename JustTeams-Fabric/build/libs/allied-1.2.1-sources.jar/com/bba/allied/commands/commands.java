package com.bba.allied.commands;

import com.bba.allied.data.datManager;
import com.bba.allied.teamUtils.teamChatManager;
import com.bba.allied.teamUtils.teamUtils;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("ALL")
public class commands {
    public static final String MOD_ID = "allied";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                class_2170.method_9247("allied")

                        .then(class_2170.method_9247("create")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                        .then(class_2170.method_9244("tag", StringArgumentType.string()).executes(context -> {
                                                    String teamName = StringArgumentType.getString(context, "name");
                                                    String teamTag = StringArgumentType.getString(context, "tag");
                                                    class_3222 player = context.getSource().method_44023();
                                                    assert player != null;
                                                    UUID ownerUuid = player.method_5667();

                                                    class_2168 source = context.getSource();
                                                    MinecraftServer server = source.method_9211();

                                                    datManager.get().addTeam(teamName, teamTag, ownerUuid);

                                                    teamUtils.rebuildTeams(server);

                                                    context.getSource().method_9226(
                                                            () -> class_2561.method_30163("Successfully created team " + teamName),
                                                            false
                                                    );
                                                    return 1;
                                                })
                                        )
                                )
                        )

                        .then(class_2170.method_9247("disband")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    assert player != null;
                                    UUID ownerUuid = player.method_5667();
                                    try {
                                        datManager.get().removeTeam(ownerUuid);
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }

                                    class_2168 source = context.getSource();
                                    MinecraftServer server = source.method_9211();

                                    teamUtils.rebuildTeams(server);

                                    context.getSource().method_9226(
                                            () -> class_2561.method_30163("Successfully Disbanded team"),
                                            false
                                    );
                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("leave")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    assert player != null;
                                    UUID ownerUuid = player.method_5667();
                                    try {
                                        datManager.get().leaveTeam(ownerUuid);
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }

                                    class_2168 source = context.getSource();
                                    MinecraftServer server = source.method_9211();

                                    teamUtils.rebuildTeams(server);

                                    context.getSource().method_9226(
                                            () -> class_2561.method_30163("Successfully left team"),
                                            false
                                    );
                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("tm")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    UUID uuid = player.method_5667();

                                    if (!datManager.get().isInTeam(uuid)) {
                                        context.getSource().method_9213(class_2561.method_43470("You are not in a team!"));
                                        return 0;
                                    }

                                    boolean enabled = teamChatManager.toggle(uuid);
                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470(enabled ? "Team Chat Enabled" : "Team Chat Disabled"),
                                            false
                                    );
                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("join")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                    .executes(context -> {
                                        String teamName = StringArgumentType.getString(context, "name");
                                        class_3222 player = context.getSource().method_44023();
                                        assert player != null;
                                        UUID ownerUuid = player.method_5667();

                                        class_2168 source = context.getSource();
                                        MinecraftServer server = source.method_9211();

                                        datManager.get().sendRequest(teamName, ownerUuid, server);

                                        context.getSource().method_9226(
                                                () -> class_2561.method_30163("Sent Request to " + teamName),
                                                false
                                        );
                                        return 1;
                                    })
                                )
                        )

                        .then(class_2170.method_9247("accept")
                                .then(class_2170.method_9244("playerName", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            context.getSource().method_9211().method_3760().method_14571().forEach(player -> builder.suggest(player.method_7334().name()));
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 owner = context.getSource().method_44023();
                                            assert owner != null;
                                            UUID ownerUUID = owner.method_5667();

                                            String targetName = StringArgumentType.getString(context, "playerName");
                                            UUID targetUUID;

                                            try {
                                                targetUUID = UUID.fromString(targetName);
                                            } catch (IllegalArgumentException e) {
                                                class_3222 targetPlayer = context.getSource().method_9211()
                                                        .method_3760()
                                                        .method_14566(targetName);

                                                if (targetPlayer == null) {
                                                    context.getSource().method_9213(class_2561.method_43470("Player not found or not online!"));
                                                    return 0;
                                                }

                                                targetUUID = targetPlayer.method_5667();
                                            }

                                            try {
                                                datManager.get().handleRequest(ownerUUID, targetUUID, true);
                                            } catch (CommandSyntaxException e) {
                                                context.getSource().method_9213((class_2561) e.getRawMessage());
                                                return 0;
                                            } catch (IOException e) {
                                                context.getSource().method_9213(class_2561.method_43470("An internal error occurred while saving the team data."));
                                                e.printStackTrace();
                                                return 0;
                                            }

                                            class_2168 source = context.getSource();
                                            MinecraftServer server = source.method_9211();
                                            teamUtils.rebuildTeams(server);

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Accepted join request from " + targetName),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("deny")
                                .then(class_2170.method_9244("playerName", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            context.getSource().method_9211().method_3760().method_14571().forEach(player -> builder.suggest(player.method_7334().name()));
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 owner = context.getSource().method_44023();
                                            assert owner != null;
                                            UUID ownerUUID = owner.method_5667();

                                            String targetName = StringArgumentType.getString(context, "playerName");
                                            class_3222 targetPlayer = context.getSource().method_9211()
                                                    .method_3760().method_14566(targetName);

                                            if (targetPlayer == null) {
                                                context.getSource().method_9213(class_2561.method_43470("Player not found or not online!"));
                                                return 0;
                                            }

                                            UUID targetUUID = targetPlayer.method_5667();

                                            try {
                                                datManager.get().handleRequest(ownerUUID, targetUUID, false);
                                            } catch (IOException | CommandSyntaxException e) {
                                                throw new RuntimeException(e);
                                            }

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Denied join request from " + targetName),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("invite")
                                .then(class_2170.method_9244("playerName", StringArgumentType.word())
                                        .executes(context -> {
                                            class_3222 owner = context.getSource().method_44023();
                                            class_3222 target = context.getSource()
                                                    .method_9211()
                                                    .method_3760()
                                                    .method_14566(StringArgumentType.getString(context, "playerName"));

                                            if (target == null) {
                                                context.getSource().method_9213(class_2561.method_43470("Player not online!"));
                                                return 0;
                                            }

                                            try {
                                                datManager.get().sendInvite(
                                                        owner.method_5667(),
                                                        target.method_5667(),
                                                        context.getSource().method_9211()
                                                );
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                return 0;
                                            }

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Invite sent."),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("invAccept")
                                .then(class_2170.method_9244("teamName", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player != null) {
                                                datManager.get()
                                                        .getInvitedTeams(player.method_5667())
                                                        .forEach(builder::suggest);
                                            }
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player == null) return 0;

                                            String teamName = StringArgumentType.getString(context, "teamName");

                                            try {
                                                datManager.get().handleInvite(
                                                        player.method_5667(),
                                                        teamName,
                                                        true
                                                );
                                            } catch (CommandSyntaxException e) {
                                                context.getSource().method_9213((class_2561) e.getRawMessage());
                                                return 0;
                                            } catch (IOException e) {
                                                context.getSource().method_9213(class_2561.method_43470("Failed to save team data."));
                                                e.printStackTrace();
                                                return 0;
                                            }

                                            teamUtils.rebuildTeams(context.getSource().method_9211());

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Joined team ")
                                                            .method_10852(class_2561.method_43470(teamName).method_27692(class_124.field_1054)),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("invDeny")
                                .then(class_2170.method_9244("teamName", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player != null) {
                                                datManager.get()
                                                        .getInvitedTeams(player.method_5667())
                                                        .forEach(builder::suggest);
                                            }
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player == null) return 0;

                                            String teamName = StringArgumentType.getString(context, "teamName");

                                            try {
                                                datManager.get().handleInvite(
                                                        player.method_5667(),
                                                        teamName,
                                                        false
                                                );
                                            } catch (CommandSyntaxException e) {
                                                context.getSource().method_9213((class_2561) e.getRawMessage());
                                                return 0;
                                            } catch (IOException e) {
                                                context.getSource().method_9213(class_2561.method_43470("Failed to save team data."));
                                                e.printStackTrace();
                                                return 0;
                                            }

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Denied invite from ")
                                                            .method_10852(class_2561.method_43470(teamName).method_27692(class_124.field_1054)),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("info")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    if (player == null) return 0;

                                    String playerUuid = player.method_5667().toString();
                                    class_2487 teams = datManager.get().getData().method_68568("teams");

                                    class_2487 playerTeam = null;
                                    String teamName = null;

                                    for (String key : teams.method_10541()) {
                                        class_2487 team = teams.method_68568(key);

                                        if (team.method_10558("owner").orElse("").equals(playerUuid)) {
                                            playerTeam = team;
                                            teamName = key;
                                            break;
                                        }

                                        var members = team.method_68569("members");
                                        for (int i = 0; i < members.size(); i++) {
                                            if (members.method_10608(i).orElse("").equals(playerUuid)) {
                                                playerTeam = team;
                                                teamName = key;
                                                break;
                                            }
                                        }

                                        if (playerTeam != null) break;
                                    }

                                    if (playerTeam == null) {
                                        context.getSource().method_9226(() -> class_2561.method_43470("You are not in a team!"), false);
                                        return 0;
                                    }

                                    String teamTag = playerTeam.method_10558("teamTag").orElse(teamName);
                                    String ownerUuid = playerTeam.method_10558("owner").orElse("");
                                    String ownerName = "Unknown";

                                    class_3222 owner = null;
                                    try {
                                        if (player.method_51469() instanceof class_3218 serverWorld) {
                                            MinecraftServer server = serverWorld.method_8503();
                                            owner = server.method_3760().method_14602(UUID.fromString(ownerUuid));
                                        }
                                        if (owner != null) ownerName = String.valueOf(owner.method_72393().method_5477().getString());
                                    } catch (IllegalArgumentException ignored) {}

                                    var membersList = playerTeam.method_68569("members");
                                    StringBuilder membersText = new StringBuilder();
                                    AtomicInteger offlineCount = new AtomicInteger();

                                    for (int i = 0; i < membersList.size(); i++) {
                                        membersList.method_10608(i).ifPresent(uuidStr -> {
                                            try {
                                                class_3222 member = null;
                                                if (player.method_51469() instanceof class_3218 serverWorld) {
                                                    MinecraftServer server = serverWorld.method_8503();
                                                    member = server.method_3760().method_14602(UUID.fromString(uuidStr));
                                                }
                                                if (member != null) {
                                                    if (membersText.length() > 0) membersText.append(", ");
                                                    membersText.append(member.method_72393().method_5477().getString());
                                                } else {
                                                    offlineCount.getAndIncrement();
                                                }
                                            } catch (IllegalArgumentException ignored) {
                                                offlineCount.getAndIncrement();
                                            }
                                        });
                                    }

                                    if (offlineCount.get() > 0) {
                                        if (membersText.length() > 0) membersText.append(", ");
                                        membersText.append("(").append(offlineCount.get()).append(") Offline");
                                    }

                                    class_2561 infoMessage = class_2561.method_43470("§6=== Team Info ===\n")
                                            .method_10852(class_2561.method_43470("§eTeam Name: §f" + teamName + "\n"))
                                            .method_10852(class_2561.method_43470("§eTeam Tag: §f" + teamTag + "\n"))
                                            .method_10852(class_2561.method_43470("§eOwner: §f" + ownerName + "\n"))
                                            .method_10852(class_2561.method_43470("§eMembers: §f" + (membersText.length() > 0 ? membersText : "None")));

                                    context.getSource().method_9226(() -> infoMessage, false);

                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("settings")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    assert player != null;

                                    String teamName = datManager.get().getTeam(player.method_5667());
                                    if (teamName != null) {
                                        class_2499 blocked = datManager.get()
                                                .getData()
                                                .method_68568("settings")
                                                .method_68569("blockTeamsSettings");

                                        for (int i = 0; i < blocked.size(); i++) {
                                            if (teamName.equalsIgnoreCase(blocked.method_10608(i).orElse(""))) {
                                                context.getSource().method_9213(
                                                        class_2561.method_43470(
                                                                "Server Admin has disabled you from changing your team settings, please contact the Server's Admin!"
                                                        )
                                                );
                                                return 0;
                                            }
                                        }
                                    }

                                    try {
                                        assert player != null;
                                        datManager.get().handleSettings(player, null, null);
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                    return 1;
                                })
                                .then(class_2170.method_9244("setting", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            class_3222 player = context.getSource().method_44023();
                                            class_2487 teams = datManager.get().getData().method_68568("teams");

                                            class_2487 teamData = null;
                                            for (String teamName : teams.method_10541()) {
                                                class_2487 team = teams.method_68568(teamName);
                                                assert player != null;
                                                if (team.method_10558("owner").orElse("").equals(player.method_5667().toString())) {
                                                    teamData = team;
                                                    break;
                                                }
                                            }

                                            if (teamData == null) return builder.buildFuture();

                                            class_2487 settings = teamData.method_68568("settings");
                                            for (String key : settings.method_10541()) builder.suggest(key);

                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 player = context.getSource().method_44023();
                                            assert player != null;

                                            String teamName = datManager.get().getTeam(player.method_5667());
                                            if (teamName != null) {
                                                class_2499 blocked = datManager.get()
                                                        .getData()
                                                        .method_68568("settings")
                                                        .method_68569("blockTeamsSettings");

                                                for (int i = 0; i < blocked.size(); i++) {
                                                    if (teamName.equalsIgnoreCase(blocked.method_10608(i).orElse(""))) {
                                                        context.getSource().method_9213(
                                                                class_2561.method_43470(
                                                                        "Server Admin has disabled you from changing your team settings, please contact the Server's Admin!"
                                                                )
                                                        );
                                                        return 0;
                                                    }
                                                }
                                            }

                                            String setting = StringArgumentType.getString(context, "setting");
                                            try {
                                                assert player != null;
                                                datManager.get().handleSettings(player, setting, null);
                                            } catch (IOException e) {
                                                throw new RuntimeException(e);
                                            }
                                            return 1;
                                        })
                                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                                .executes(context -> {
                                                    class_3222 player = context.getSource().method_44023();
                                                    assert player != null;

                                                    String teamName = datManager.get().getTeam(player.method_5667());
                                                    if (teamName != null) {
                                                        class_2499 blocked = datManager.get()
                                                                .getData()
                                                                .method_68568("settings")
                                                                .method_68569("blockTeamsSettings");

                                                        for (int i = 0; i < blocked.size(); i++) {
                                                            if (teamName.equalsIgnoreCase(blocked.method_10608(i).orElse(""))) {
                                                                context.getSource().method_9213(
                                                                        class_2561.method_43470(
                                                                                "Server Admin has disabled you from changing your team settings, please contact the Server's Admin!"
                                                                        )
                                                                );
                                                                return 0;
                                                            }
                                                        }
                                                    }

                                                    String setting = StringArgumentType.getString(context, "setting");
                                                    boolean value = BoolArgumentType.getBool(context, "value");

                                                    try {
                                                        assert player != null;
                                                        datManager.get().handleSettings(player, setting, value);
                                                    } catch (IOException e) {
                                                        throw new RuntimeException(e);
                                                    }

                                                    class_2168 source = context.getSource();
                                                    MinecraftServer server = source.method_9211();
                                                    teamUtils.rebuildTeams(server);

                                                    context.getSource().method_9226(
                                                            () -> class_2561.method_43470("Setting '" + setting + "' updated to " + value),
                                                            false
                                                    );
                                                    return 1;
                                                })
                                        )
                                )
                        )

                        .then(class_2170.method_9247("set")
                                .then(class_2170.method_9244("field", StringArgumentType.word())
                                        .suggests((ctx, builder) -> {
                                            builder.suggest("name");
                                            builder.suggest("tag");
                                            builder.suggest("color");
                                            return builder.buildFuture();
                                        })
                                        .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                                                .suggests((ctx, builder) -> {
                                                    String field = StringArgumentType.getString(ctx, "field");
                                                    if (field.equalsIgnoreCase("color")) {
                                                        for (class_124 f : class_124.values()) {
                                                            if (f.method_543()) {
                                                                builder.suggest(f.method_537());
                                                            }
                                                        }
                                                    }
                                                    return builder.buildFuture();
                                                })
                                                .executes(context -> {
                                                    String field = StringArgumentType.getString(context, "field");
                                                    String value = StringArgumentType.getString(context, "value");
                                                    class_3222 player = context.getSource().method_44023();

                                                    try {
                                                        assert player != null;
                                                        datManager.get().executeSet(player, field, value);
                                                    } catch (IOException e) {
                                                        throw new RuntimeException(e);
                                                    }

                                                    class_2168 source = context.getSource();
                                                    MinecraftServer server = source.method_9211();
                                                    teamUtils.rebuildTeams(server);

                                                    context.getSource().method_9226(
                                                            () -> class_2561.method_43470("Successfully updated  " + field),
                                                            false
                                                    );
                                                    return 1;
                                                })
                                        )
                                )
                        )

                        .then(class_2170.method_9247("kick")
                                .then(class_2170.method_9244("playerName", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            class_3222 owner = context.getSource().method_44023();
                                            if (owner == null) return builder.buildFuture();

                                            class_2487 teams = datManager.get().getData().method_68568("teams");
                                            String ownerStr = owner.method_5667().toString();
                                            class_2487 teamData = null;

                                            for (String tName : teams.method_10541()) {
                                                class_2487 t = teams.method_68568(tName);
                                                if (ownerStr.equals(t.method_10558("owner").orElse(""))) {
                                                    teamData = t;
                                                    break;
                                                }
                                            }

                                            if (teamData == null) return builder.buildFuture();
                                            MinecraftServer server = context.getSource().method_9211();
                                            class_2499 members = teamData.method_68569("members");
                                            for (int i = 0; i < members.size(); i++) {
                                                String memberUUID = members.method_10608(i).orElse("");
                                                if (!ownerStr.equals(memberUUID)) {
                                                    class_3222 member = server.method_3760().method_14602(UUID.fromString(memberUUID));

                                                    if (member != null) builder.suggest(member.method_7334().name());
                                                }
                                            }

                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            class_3222 owner = context.getSource().method_44023();
                                            if (owner == null) return 0;

                                            String targetName = StringArgumentType.getString(context, "playerName");
                                            MinecraftServer server = context.getSource().method_9211();
                                            class_3222 target = server.method_3760().method_14566(targetName);
                                            if (target == null) {
                                                context.getSource().method_9213(class_2561.method_43470("Player not found or not online!"));
                                                return 0;
                                            }

                                            try {
                                                datManager.get().kickMember(owner, target);
                                            } catch (IOException e) {
                                                context.getSource().method_9213(class_2561.method_43470("Failed to save team data."));
                                                e.printStackTrace();
                                                return 0;
                                            }

                                            teamUtils.rebuildTeams(server);

                                            return 1;
                                        })
                                )
                        )

        ));

        LOGGER.info("Commands Registered!");
    }
}
