package com.bba.allied.commands;

import com.bba.allied.data.datManager;
import com.bba.allied.teamUtils.teamUtils;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class adminCommands {

    private static final Map<UUID, Confirmation> pendingResets = new HashMap<>();

    public record Confirmation(String code, long expiryTime) {
    }

    private static String generateCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(chars.charAt(rand.nextInt(chars.length())));
        }
        return sb.toString();
    }

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                class_2170.method_9247("alliedAdmin")
                        .requires(class_2170.method_71774(class_2170.field_31840))
                        .then(class_2170.method_9247("memberCap")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer(1))
                                        .executes(context -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player == null) return 0;

                                            int newCap = IntegerArgumentType.getInteger(context, "value");
                                            class_2487 data = datManager.get().getData();
                                            class_2487 settings = data.method_68568("settings");
                                            settings.method_10569("maxMembers", newCap);

                                            try {
                                                datManager.get().save();
                                            } catch (IOException e) {
                                                throw new RuntimeException(e);
                                            }

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("Team member cap set to " + newCap),
                                                    false
                                            );
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("info")
                                .then(class_2170.method_9244("teamName", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            datManager.get().getData().method_68568("teams").method_10541()
                                                    .forEach(builder::suggest);
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            MinecraftServer server = context.getSource().method_9211();
                                            String teamName = StringArgumentType.getString(context, "teamName");

                                            class_2561 info = datManager.get().getTeamInfo(server, teamName);

                                            context.getSource().method_9226(() -> info, false);
                                            return 1;
                                        })
                                )
                        )

                        .then(class_2170.method_9247("list")
                                .executes(context -> {
                                    class_2487 teams = datManager.get().getData().method_68568("teams");

                                    if (teams.method_33133()) {
                                        context.getSource().method_9226(
                                                () -> class_2561.method_43470("There are no teams on the server."),
                                                false
                                        );
                                        return 1;
                                    }

                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470("Teams on the server:")
                                                    .method_27692(class_124.field_1065),
                                            false
                                    );

                                    for (String teamName : teams.method_10541()) {
                                        context.getSource().method_9226(
                                                () -> class_2561.method_43470("- ")
                                                        .method_27692(class_124.field_1080)
                                                        .method_10852(class_2561.method_43470(teamName).method_27692(class_124.field_1054)),
                                                false
                                        );
                                    }

                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("reset")
                                .then(class_2170.method_9244("code", StringArgumentType.string())
                                        .executes(context -> {
                                            class_3222 player = context.getSource().method_44023();
                                            if (player == null) return 0;

                                            UUID uuid = player.method_5667();
                                            String enteredCode = StringArgumentType.getString(context, "code");
                                            Confirmation confirm = pendingResets.get(uuid);

                                            if (confirm == null || System.currentTimeMillis() > confirm.expiryTime) {
                                                context.getSource().method_9213(class_2561.method_43470("You haven't started a reset or the code has expired!"));
                                                pendingResets.remove(uuid);
                                                return 0;
                                            }

                                            if (!confirm.code.equalsIgnoreCase(enteredCode)) {
                                                context.getSource().method_9213(class_2561.method_43470("Incorrect code!"));
                                                return 0;
                                            }

                                            MinecraftServer server = context.getSource().method_9211();

                                            try {
                                                datManager.get().resetData(server);
                                            } catch (IOException e) {
                                                throw new RuntimeException(e);
                                            }
                                            pendingResets.remove(uuid);

                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("All team data has been wiped!").method_27692(class_124.field_1061),
                                                    false
                                            );

                                            return 1;
                                        })
                                )
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_44023();
                                    if (player == null) return 0;

                                    UUID uuid = player.method_5667();
                                    if (pendingResets.containsKey(uuid)) {
                                        context.getSource().method_9213(class_2561.method_43470(
                                                "You already have a pending reset! Enter your existing code or wait until it expires."
                                        ));
                                        return 0;
                                    }

                                    String code = generateCode();
                                    long expiry = System.currentTimeMillis() + 60_000;
                                    pendingResets.put(uuid, new Confirmation(code, expiry));

                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470("⚠ Are you sure you want to continue? This will wipe all data!").method_27692(class_124.field_1061),
                                            false
                                    );

                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470("Please enter the code to confirm: /alliedAdmin reset " + code).method_27692(class_124.field_1054),
                                            false
                                    );

                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("blockSettings")
                                .then(class_2170.method_9244("teamName", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            datManager.get().getData()
                                                    .method_68568("teams")
                                                    .method_10541()
                                                    .forEach(builder::suggest);
                                            return builder.buildFuture();
                                        })
                                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                                .executes(context -> {
                                                    String teamName = StringArgumentType.getString(context, "teamName");
                                                    boolean value = BoolArgumentType.getBool(context, "value");

                                                    class_2487 data = datManager.get().getData();
                                                    class_2487 teams = data.method_68568("teams");

                                                    if (!teams.method_10545(teamName)) {
                                                        context.getSource().method_9213(
                                                                class_2561.method_43470("Team '" + teamName + "' does not exist!")
                                                        );
                                                        return 0;
                                                    }

                                                    class_2487 settings = data.method_68568("settings");
                                                    class_2499 blocked = settings.method_68569("blockTeamsSettings");

                                                    int index = -1;
                                                    for (int i = 0; i < blocked.size(); i++) {
                                                        if (teamName.equalsIgnoreCase(blocked.method_10608(i).orElse(""))) {
                                                            index = i;
                                                            break;
                                                        }
                                                    }

                                                    if (value) {
                                                        if (index != -1) {
                                                            context.getSource().method_9213(
                                                                    class_2561.method_43470("This team is already blocked!")
                                                            );
                                                            return 0;
                                                        }

                                                        blocked.add(class_2519.method_23256(teamName));
                                                        context.getSource().method_9226(
                                                                () -> class_2561.method_43470("Team '" + teamName + "' is now blocked from changing settings."),
                                                                false
                                                        );
                                                    } else {
                                                        if (index == -1) {
                                                            context.getSource().method_9213(
                                                                    class_2561.method_43470("This team is not blocked already!")
                                                            );
                                                            return 0;
                                                        }

                                                        blocked.remove(index);
                                                        context.getSource().method_9226(
                                                                () -> class_2561.method_43470("Team '" + teamName + "' can now change settings."),
                                                                false
                                                        );
                                                    }

                                                    settings.method_10566("blockTeamsSettings", blocked);

                                                    try {
                                                        datManager.get().save();
                                                    } catch (IOException e) {
                                                        throw new RuntimeException(e);
                                                    }

                                                    return 1;
                                                })
                                        )
                                )
                        )

                        .then(class_2170.method_9247("modifySettings")
                                .then(class_2170.method_9244("teamName", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            datManager.get().getData().method_68568("teams").method_10541()
                                                    .forEach(builder::suggest);
                                            return builder.buildFuture();
                                        })
                                        .executes(context -> {
                                            String teamName = StringArgumentType.getString(context, "teamName");
                                            class_3222 player = context.getSource().method_44023();
                                            assert player != null;

                                            try {
                                                datManager.get().handleSettingsAdmin(player.method_64396(), teamName, null, null);
                                            } catch (IOException | CommandSyntaxException e) {
                                                throw new RuntimeException(e);
                                            }

                                            return 1;
                                        })
                                        .then(class_2170.method_9244("setting", StringArgumentType.string())
                                                .suggests((context, builder) -> {
                                                    String teamName = StringArgumentType.getString(context, "teamName");
                                                    class_2487 teams = datManager.get().getData().method_68568("teams");
                                                    class_2487 teamData = teams.method_68568(teamName);

                                                    class_2487 settings = teamData.method_68568("settings");
                                                    for (String key : settings.method_10541()) builder.suggest(key);

                                                    return builder.buildFuture();
                                                })
                                                .executes(context -> {
                                                    String teamName = StringArgumentType.getString(context, "teamName");
                                                    String setting = StringArgumentType.getString(context, "setting");
                                                    class_3222 player = context.getSource().method_44023();
                                                    assert player != null;

                                                    try {
                                                        datManager.get().handleSettingsAdmin(player.method_64396(), teamName, setting, null);
                                                    } catch (IOException | CommandSyntaxException e) {
                                                        throw new RuntimeException(e);
                                                    }

                                                    return 1;
                                                })
                                                .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                                        .executes(context -> {
                                                            String teamName = StringArgumentType.getString(context, "teamName");
                                                            String setting = StringArgumentType.getString(context, "setting");
                                                            boolean value = BoolArgumentType.getBool(context, "value");
                                                            class_3222 player = context.getSource().method_44023();
                                                            assert player != null;

                                                            try {
                                                                datManager.get().handleSettingsAdmin(player.method_64396(), teamName, setting, value);
                                                            } catch (IOException | CommandSyntaxException e) {
                                                                throw new RuntimeException(e);
                                                            }

                                                            teamUtils.rebuildTeams(context.getSource().method_9211());

                                                            context.getSource().method_9226(
                                                                    () -> class_2561.method_43470("Admin set '" + setting + "' for team '" + teamName + "' to " + value),
                                                                    false
                                                            );
                                                            return 1;
                                                        })
                                                )
                                        )
                                )
                        )


        ));
    }
}
