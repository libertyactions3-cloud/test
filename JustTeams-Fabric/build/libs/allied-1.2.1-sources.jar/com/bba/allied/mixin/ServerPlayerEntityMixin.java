package com.bba.allied.mixin;

import com.bba.allied.data.datManager;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "getPlayerListName", at = @At("RETURN"), cancellable = true)
    private void allied$tablistName(CallbackInfoReturnable<class_2561> cir) {
        class_3222 player = (class_3222) (Object) this;

        class_2487 teams = datManager.get().getData().method_68568("teams");
        String uuid = player.method_5667().toString();

        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);

            boolean isOwner = team.method_10558("owner").orElse("").equals(uuid);
            boolean isMember = team.method_68569("members")
                    .stream()
                    .anyMatch(e -> e.method_68658().orElse("").equals(uuid));

            if (isOwner || isMember) {
                boolean tabUseTag = team.method_68568("settings").method_10577("tabUseTag").orElse(true);
                String tag;
                if (tabUseTag) {
                    tag = team.method_10558("teamTag").orElse(teamName).toUpperCase();
                } else {
                    tag = teamName.toUpperCase();
                }
                String colorStr = team.method_10558("tagColor").orElse("WHITE");

                class_124 tagColor;
                try {
                    tagColor = class_124.valueOf(colorStr.toUpperCase());
                } catch (IllegalArgumentException e) {
                    tagColor = class_124.field_1068;
                }

                class_2561 tabName = class_2561.method_43470("[")
                        .method_27692(class_124.field_1068)
                        .method_10852(class_2561.method_43470(tag).method_27692(tagColor))
                        .method_10852(class_2561.method_43470("] "))
                        .method_10852(player.method_5477()).method_27692(class_124.field_1068);

                cir.setReturnValue(tabName);
                return;
            }
        }

        cir.setReturnValue(player.method_5477());
    }
}
