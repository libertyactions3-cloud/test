package com.bba.allied.data;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class datConfig {
    public static final String MOD_ID = "allied";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    static Path path = FabricLoader.getInstance().getConfigDir().resolve("allied").resolve("teams.dat");

    public static void InitialiseDatFolder() throws IOException {
        Files.createDirectories(path.getParent());
        class_2487 root = CreateDefault();
        if (!Files.exists(path)) {
            class_2507.method_10630(root, path);
            datManager.init(root);
            LOGGER.info("Loaded Default .Dat File...");
        } else {
            root = class_2507.method_10633(path);
            datManager.init(root);
            LOGGER.info("Loaded existing .Dat File...");
        }
    }

    public static class_2487 CreateDefault() {
        class_2487 root = new class_2487();

        root.method_10582("version", "1.0.0");

        class_2487 teams = new class_2487();
        root.method_10566("teams", teams);

        class_2487 settings = new class_2487();
        root.method_10566("settings", settings);

        settings.method_10569("maxMembers", 5);
        settings.method_10556("echest", true);
        class_2499 blockTeamsSettings = new class_2499();
        settings.method_10566("blockTeamsSettings", blockTeamsSettings);

        return root;
    }
}

