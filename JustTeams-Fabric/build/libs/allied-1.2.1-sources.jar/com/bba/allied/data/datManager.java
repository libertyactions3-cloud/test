package com.bba.allied.data;

import com.bba.allied.teamUtils.teamUtils;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2519;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.*;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

import static com.bba.allied.data.datConfig.CreateDefault;
import static com.bba.allied.teamUtils.teamUtils.toTeamId;

public class datManager {
    public static final String MOD_ID = "allied";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    Path path = FabricLoader.getInstance().getConfigDir().resolve("allied").resolve("teams.dat");

    private static datManager INSTANCE;
    private class_2487 data;

    private datManager(class_2487 data) {
        this.data = data;
    }

    public static void init(class_2487 data) {
        INSTANCE = new datManager(data);
    }

    public void resetData(MinecraftServer server) throws IOException {
        data = CreateDefault();
        save();
        datConfig.InitialiseDatFolder();

        LOGGER.info("ALLIED MOD DATA HAS BEEN RESET!");

        teamUtils.rebuildTeams(server);
    }

    public static datManager get() {
        if (INSTANCE == null) throw new IllegalStateException("datManager not initialized!");
        return INSTANCE;
    }

    public class_2487 getData() {
        return data;
    }

    public void save() throws IOException {
        class_2507.method_10630(data, path);
    }

    public boolean isOwnerOfATeam(UUID uuid) {
        class_2487 teams = data.method_68568("teams");
        String ownerStr = uuid.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);
            Optional<String> storedOwner = teamData.method_10558("owner");

            if (ownerStr.equalsIgnoreCase(storedOwner.orElse(null))) {
                return true;
            }
        }
        return false;
    }

    public boolean isMemberOfATeam(UUID uuid) {
        class_2487 teams = data.method_68568("teams");
        String uuidStr = uuid.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);
            class_2499 members = teamData.method_68569("members");

            for (int i = 0; i < members.size(); i++) {
                if (uuidStr.equalsIgnoreCase(members.method_10608(i).orElse(null))) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isInTeam(UUID uuid) {
        return isOwnerOfATeam(uuid) || isMemberOfATeam(uuid);
    }

    public String getTeam(UUID playerUuid) {
        class_2487 teams = data.method_68568("teams");
        String playerId = playerUuid.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);

            if (team.method_10558("owner").orElse("").equalsIgnoreCase(playerId)) {
                return teamName;
            }

            var members = team.method_68569("members");
            for (int i = 0; i < members.size(); i++) {
                if (members.method_10608(i).orElse("").equalsIgnoreCase(playerId)) {
                    return teamName;
                }
            }
        }

        return null;
    }

    public void addTeam(String teamName, String teamTag, UUID ownerUUID) throws CommandSyntaxException  {
        if (isInTeam(ownerUUID)) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("You are already in a team!")
            ).create();
        }

        if (teamName.length() > 16 || teamTag.length() > 4) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("Team Name or Team Tag is too long!")
            ).create();
        }

        class_2487 teams = data.method_68568("teams");

        if (teams.method_10545(toTeamId(teamName))) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("A team with this internal name already exists!")
            ).create();
        }

        for (String existingTeamName : teams.method_10541()) {
            class_2487 existingTeam = teams.method_68568(existingTeamName);
            String existingTag = existingTeam.method_10558("teamTag").orElse("");
            if (existingTag.equalsIgnoreCase(teamTag)) {
                throw new SimpleCommandExceptionType(
                        class_2561.method_30163("A team with this tag already exists!")
                ).create();
            }
        }

        class_2487 team = createTeam(teamTag, ownerUUID);
        teams.method_10566(teamName, team);

        try {
            save();
        } catch (IOException e) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("Failed to create team, please try again!")
            ).create();
        }
    }

    public void removeTeam(UUID ownerUUID) throws CommandSyntaxException, IOException {
        class_2487 teams = data.method_68568("teams");
        String ownerStr = ownerUUID.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);
            Optional<String> storedOwner = teamData.method_10558("owner");

            if (ownerStr.equalsIgnoreCase(storedOwner.orElse(null))) {
                teams.method_10551(teamName);
                save();
                return;
            }
        }

        throw new SimpleCommandExceptionType(class_2561.method_30163("You don't own a team!")).create();
    }

    public void leaveTeam(UUID ownerUUID) throws CommandSyntaxException, IOException {
        class_2487 teams = data.method_68568("teams");
        String ownerStr = ownerUUID.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);

            var members = teamData.method_68569("members");

            for (int i = 0; i < members.size(); i++) {
                String memberUuid = members.method_10608(i).orElse("");

                if (ownerStr.equalsIgnoreCase(memberUuid)) {
                    members.remove(i);
                    save();
                    return;
                }
            }
        }

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);
            Optional<String> storedOwner = teamData.method_10558("owner");

            if (ownerStr.equalsIgnoreCase(storedOwner.orElse(null))) {
                throw new SimpleCommandExceptionType(class_2561.method_30163("You can't leave your own team, do '/allied  disband' instead!")).create();
            }
        }

        throw new SimpleCommandExceptionType(class_2561.method_30163("You are not in a team")).create();
    }

    public int getTeamMemberCount(String teamName) {
        class_2487 teams = datManager.get().getData().method_68568("teams");
        class_2487 teamData = teams.method_68568(teamName);

        if (teamData == null || teamData.method_33133()) {
            return 0;
        }

        class_2499 members = teamData.method_68569("members");
        return members.size();
    }

    public void sendRequest(String targetTeamName, UUID playerUUID, MinecraftServer server) throws CommandSyntaxException {
        if (isInTeam(playerUUID)) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("You are in a team already!")
            ).create();
        }

        class_2487 teams = data.method_68568("teams");

        if (!teams.method_10545(targetTeamName)) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("Team does not exist!")
            ).create();
        }

        class_2487 teamData = teams.method_68568(targetTeamName);

        int count = getTeamMemberCount(targetTeamName);
        int memberCap = data.method_68568("settings").method_68083("maxMembers", 5);

        if (count >= memberCap) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("This team is full!")
            ).create();
        }

        boolean allowRequests = teamData
                .method_68568("settings")
                .method_10577("allowRequests")
                .orElse(false);
        if (!allowRequests) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("This team is not accepting requests right now!")
            ).create();
        }

        class_2499 requests = teamData.method_68569("joinRequests");
        String playerUuidStr = playerUUID.toString();

        for (int i = 0; i < requests.size(); i++) {
            if (requests.get(i).method_10711() == 8) {
                String existing = requests.method_10608(i).orElse(null);
                assert existing != null;
                if (existing.equalsIgnoreCase(playerUuidStr)) {
                    throw new SimpleCommandExceptionType(
                            class_2561.method_30163("You have already requested to join this team!")
                    ).create();
                }
            }
        }

        requests.add(class_2519.method_23256(playerUuidStr));
        try {
            save();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save join request", e);
        }

        class_3222 player = server.method_3760().method_14602(playerUUID);
        String requesterName = "";
        if (player != null) {
            requesterName = player.method_7334().name();
        }

        class_3222 owner = server.method_3760()
                .method_14602(UUID.fromString(teamData.method_10558("owner").orElseThrow()));

        if (owner != null) {
            class_2561 accept = class_2561.method_43470("[ACCEPT]")
                    .method_27692(class_124.field_1060)
                    .method_27694(style -> style
                            .method_10958(new class_2558.class_10609("/allied accept"+ " " + playerUUID))
                            .method_10949(new class_2568.class_10613(class_2561.method_43470("Accept join request")))
                    );

            class_2561 deny = class_2561.method_43470("[DENY]")
                    .method_27692(class_124.field_1061)
                    .method_27694(style -> style
                            .method_10958(new class_2558.class_10609("/allied deny" + " " + playerUUID))
                            .method_10949(new class_2568.class_10613(class_2561.method_43470("Deny join request")))
                    );

            owner.method_7353(
                    class_2561.method_43470( requesterName + " wants to join your team ")
                            .method_10852(class_2561.method_43470(targetTeamName).method_27692(class_124.field_1054))
                            .method_10852(class_2561.method_43470("\n"))
                            .method_10852(accept)
                            .method_10852(class_2561.method_43470(" "))
                            .method_10852(deny),
                    false
            );
        }
    }

    public void handleRequest(UUID ownerUUID, UUID requesterUUID, boolean accept) throws IOException, CommandSyntaxException {
        class_2487 teams = data.method_68568("teams");
        String ownerStr = ownerUUID.toString();

        class_2487 teamData = null;

        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);
            String storedOwner = team.method_10558("owner").orElseThrow();
            if (ownerStr.equalsIgnoreCase(storedOwner)) {
                teamData = team;
                break;
            }
        }

        if (teamData == null || teamData.method_33133()) {
            throw new SimpleCommandExceptionType(class_2561.method_30163("You do not own a team!")).create();
        }

        class_2499 requests = teamData.method_68569("joinRequests");
        String requesterStr = requesterUUID.toString();

        boolean found = false;
        for (int i = 0; i < requests.size(); i++) {
            String requestUUID = requests.method_10608(i).orElseThrow( );
            if (requesterStr.equals(requestUUID)) {
                found = true;
                requests.remove(i);
                break;
            }
        }

        if (!found) {
            throw new SimpleCommandExceptionType(class_2561.method_30163("No pending request from this player!")).create();
        }

        if (accept) {
            class_2499 members = teamData.method_68569("members");
            members.add(class_2519.method_23256(requesterStr));
        }

        save();
    }

    public void sendInvite(UUID ownerUUID, UUID targetUUID, MinecraftServer server)
            throws CommandSyntaxException, IOException {

        class_2487 teams = data.method_68568("teams");
        String ownerStr = ownerUUID.toString();

        class_3222 targetPlayer = server.method_3760().method_14602(targetUUID);
        if (targetPlayer == null) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("Target player is not online!")).create();
        }

        if (isInTeam(targetUUID)) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("This player is already in a team!")).create();
        }

        String teamName = null;
        class_2487 teamData = null;

        for (String name : teams.method_10541()) {
            class_2487 t = teams.method_68568(name);
            if (ownerStr.equals(t.method_10558("owner").orElse(""))) {
                teamName = name;
                teamData = t;
                break;
            }
        }

        int count = getTeamMemberCount(teamName);
        int memberCap = data.method_68568("settings").method_68083("maxMembers", 5);

        if (count >= memberCap) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_30163("Your team is currently full, please kick someone!")
            ).create();
        }

        if (teamData == null) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("You do not own a team!")).create();
        }

        class_2499 invites = teamData.method_68569("invites");
        String targetStr = targetUUID.toString();

        for (int i = 0; i < invites.size(); i++) {
            if (targetStr.equals(invites.method_10608(i).orElse(""))) {
                throw new SimpleCommandExceptionType(class_2561.method_43470("Player already invited!")).create();
            }
        }

        invites.add(class_2519.method_23256(targetStr));
        save();

        String finalTeamName = teamName;
        class_2561 accept = class_2561.method_43470("[ACCEPT]")
                .method_27692(class_124.field_1060)
                .method_27694(s -> s.method_10958(
                        new class_2558.class_10609("/allied invAccept " + finalTeamName)));
        class_2561 deny = class_2561.method_43470("[DENY]")
                .method_27692(class_124.field_1061)
                .method_27694(s -> s.method_10958(
                        new class_2558.class_10609("/allied invDeny " + finalTeamName)));

        targetPlayer.method_7353(
                class_2561.method_43470("You were invited to join team ")
                        .method_10852(class_2561.method_43470(teamName).method_27692(class_124.field_1054))
                        .method_10852(class_2561.method_43470("\n"))
                        .method_10852(accept).method_10852(class_2561.method_43470(" ")).method_10852(deny),
                false
        );
    }

    public void handleInvite(UUID playerUUID, String teamName, boolean accept)
            throws IOException, CommandSyntaxException {

        class_2487 teams = data.method_68568("teams");
        String playerStr = playerUUID.toString();

        class_2487 teamData = teams.method_68568(teamName);
        if (teamData.method_33133()) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("Team does not exist!")).create();
        }

        class_2499 invites = teamData.method_68569("invites");
        boolean found = false;

        for (int i = 0; i < invites.size(); i++) {
            if (playerStr.equals(invites.method_10608(i).orElse(""))) {
                invites.remove(i);
                found = true;
                break;
            }
        }

        if (!found) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("You do not have an invite to this team!")).create();
        }

        if (accept) {
            if (isInTeam(playerUUID)) {
                throw new SimpleCommandExceptionType(class_2561.method_43470("You are already in a team!")).create();
            }

            class_2499 members = teamData.method_68569("members");
            members.add(class_2519.method_23256(playerStr));

            for (String name : teams.method_10541()) {
                class_2487 t = teams.method_68568(name);
                class_2499 otherInvites = t.method_68569("invites");

                for (int i = otherInvites.size() - 1; i >= 0; i--) {
                    if (playerStr.equals(otherInvites.method_10608(i).orElse(""))) {
                        otherInvites.remove(i);
                    }
                }
            }
        }

        save();
    }

    public List<String> getInvitedTeams(UUID playerUUID) {
        List<String> result = new ArrayList<>();

        class_2487 teams = data.method_68568("teams");
        String playerStr = playerUUID.toString();

        for (String teamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(teamName);
            class_2499 invites = teamData.method_68569("invites");

            for (int i = 0; i < invites.size(); i++) {
                if (playerStr.equals(invites.method_10608(i).orElse(""))) {
                    result.add(teamName);
                    break;
                }
            }
        }

        return result;
    }

    public void handleSettings(class_3222 player, @Nullable String settingKey, @Nullable Boolean value) throws CommandSyntaxException, IOException {
        class_2487 teams = data.method_68568("teams");
        String teamName = null;

        UUID playerUUID = player.method_5667();
        for (String key : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(key);
            String owner = teamData.method_10558("owner").orElse("");
            if (owner.equalsIgnoreCase(playerUUID.toString())) {
                teamName = key;
                break;
            }
        }

        if (teamName == null) {
            throw new SimpleCommandExceptionType(class_2561.method_30163("You don't own a team!")).create();
        }

        class_2487 teamData = teams.method_68568(teamName);
        class_2487 settings = teamData.method_68568("settings");

        if (settingKey == null || value == null) {
            showTeamSettings(player, teamName);
            return;
        }

        if (!settings.method_10545(settingKey)) {
            throw new SimpleCommandExceptionType(class_2561.method_30163("Setting '" + settingKey + "' does not exist!")).create();
        }

        settings.method_10556(settingKey, value);
        save();
    }

    public void showTeamSettings(class_3222 player, String teamName) {
        class_2487 teams = datManager.get().getData().method_68568("teams");
        class_2487 teamData = teams.method_68568(teamName);
        class_2487 settings = teamData.method_68568("settings");

        class_5250 message = class_2561.method_43470("Team Settings for " + teamName + ":");

        for (String key : settings.method_10541()) {
            boolean value = settings.method_10577(key).orElse(false);

            class_2561 status = class_2561.method_43470(value ? "☑" : "☒").method_27692(value ? class_124.field_1060 : class_124.field_1061);
            class_2561 enableButton = class_2561.method_43470("[ENABLE]")
                    .method_27694(style -> style
                            .method_10977(class_124.field_1060)
                            .method_10958(new class_2558.class_10609("/allied settings" + " " + key + " " + true))
                            .method_10949(new class_2568.class_10613(class_2561.method_43470("Enable " + key)))
                    );

            class_2561 disableButton = class_2561.method_43470("[DISABLE]")
                    .method_27694(style -> style
                            .method_10977(class_124.field_1061)
                            .method_10958(new class_2558.class_10609("/allied settings" + " " + key + " " + false))
                            .method_10949(new class_2568.class_10613(class_2561.method_43470("Disable " + key)))
                    );

            message.method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470("\n" + key + ": "))
                    .method_10852(status)
                    .method_10852(class_2561.method_43470("\n "))
                    .method_10852(enableButton)
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(disableButton);
        }

        player.method_7353(message, false);
    }

    public void handleSettingsAdmin(
            class_2168 source,
            String teamName,
            @Nullable String settingKey,
            @Nullable Boolean value
    ) throws CommandSyntaxException, IOException {

        class_2487 teams = data.method_68568("teams");

        if (!teams.method_10545(teamName)) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_43470("Team '" + teamName + "' does not exist!")
            ).create();
        }

        class_2487 teamData = teams.method_68568(teamName);
        class_2487 settings = teamData.method_68568("settings");

        if (settingKey == null || value == null) {
            showTeamSettingsAdmin(source, teamName);
            return;
        }

        if (!settings.method_10545(settingKey)) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_43470("Setting '" + settingKey + "' does not exist!")
            ).create();
        }

        settings.method_10556(settingKey, value);
        save();
    }

    public void showTeamSettingsAdmin(class_2168 source, String teamName) {
        class_2487 teams = data.method_68568("teams");
        class_2487 teamData = teams.method_68568(teamName);
        class_2487 settings = teamData.method_68568("settings");

        class_5250 message = class_2561.method_43470("Admin Settings for " + teamName + ":")
                .method_27692(class_124.field_1054);

        for (String key : settings.method_10541()) {
            boolean value = settings.method_10577(key).orElse(false);

            class_2561 status = class_2561.method_43470(value ? "☑ ENABLED" : "☒ DISABLED")
                    .method_27692(value ? class_124.field_1060 : class_124.field_1061);

            class_2561 enableButton = class_2561.method_43470("[ENABLE]")
                    .method_27694(style -> style
                            .method_10977(class_124.field_1060)
                            .method_10958(
                                    new class_2558.class_10609(
                                            "/alliedAdmin modify_settings " + teamName + " " + key + " true"
                                    )
                            )
                    );

            class_2561 disableButton = class_2561.method_43470("[DISABLE]")
                    .method_27694(style -> style
                            .method_10977(class_124.field_1061)
                            .method_10958(
                                    new class_2558.class_10609(
                                            "/alliedAdmin modify_settings " + teamName + " " + key + " false"
                                    )
                            )
                    );

            message.method_10852(class_2561.method_43470("\n"))
                    .method_10852(class_2561.method_43470(key + ": "))
                    .method_10852(status)
                    .method_10852(class_2561.method_43470("\n "))
                    .method_10852(enableButton)
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(disableButton);
        }

        source.method_9226(() -> message, false);
    }

    public void executeSet(class_3222 player, String field, String value) throws CommandSyntaxException, IOException {

        String playerUuid = player.method_5667().toString();

        class_2487 data = datManager.get().getData();
        class_2487 teams = data.method_68568("teams");

        String foundTeamName = null;
        class_2487 foundTeam = null;

        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);
            if (team.method_10558("owner").orElse("").equals(playerUuid)) {
                foundTeamName = teamName;
                foundTeam = team;
                break;
            }
        }

        if (foundTeam == null) {
            throw new SimpleCommandExceptionType(
                    class_2561.method_43470("You do not own a team.")
            ).create();
        }

        if (field.equals("name") || field.equals("tag")) {
            for (String teamName : teams.method_10541()) {
                class_2487 team = teams.method_68568(teamName);
                if (team == foundTeam) continue;

                if (field.equals("name")) {
                    if (teamName.equalsIgnoreCase(value)) {
                        throw new SimpleCommandExceptionType(
                                class_2561.method_43470("A team with that name already exists.")
                        ).create();
                    }
                }

                if (field.equals("tag")) {
                    String existingTag = team.method_10558("teamTag").orElse("");
                    if (existingTag.equalsIgnoreCase(value)) {
                        throw new SimpleCommandExceptionType(
                                class_2561.method_43470("A team with that tag already exists.")
                        ).create();
                    }
                }
            }
        }

        switch (field) {

            case "name" -> {
                teams.method_10566(value, foundTeam);
                teams.method_10551(foundTeamName);
            }

            case "tag" -> foundTeam.method_10582("teamTag", value);

            case "color" -> {
                try {
                    class_124 f = class_124.valueOf(value.toUpperCase());
                    if (!f.method_543()) throw new IllegalArgumentException();
                    foundTeam.method_10582("tagColor", f.method_537());
                } catch (Exception e) {
                    throw new SimpleCommandExceptionType(
                            class_2561.method_43470("Invalid color.")
                    ).create();
                }
            }

            default -> throw new SimpleCommandExceptionType(
                    class_2561.method_43470("Invalid field. Use name, tag, or color.")
            ).create();
        }

        datManager.get().save();

    }

    public void kickMember(class_3222 owner, class_3222 target) throws IOException {
        if (owner == null || target == null) return;

        class_2487 teams = datManager.get().getData().method_68568("teams");
        String ownerStr = owner.method_5667().toString();
        String targetStr = target.method_5667().toString();

        class_2487 teamData = null;
        for (String tName : teams.method_10541()) {
            class_2487 t = teams.method_68568(tName);
            if (ownerStr.equals(t.method_10558("owner").orElse(""))) {
                teamData = t;
                break;
            }
        }

        if (teamData == null) {
            owner.method_7353(class_2561.method_43470("You do not own a team!").method_27692(class_124.field_1061), false);
            return;
        }

        class_2499 members = teamData.method_68569("members");
        boolean removed = false;
        for (int i = 0; i < members.size(); i++) {
            if (targetStr.equals(members.method_10608(i).orElse(""))) {
                members.remove(i);
                removed = true;
                break;
            }
        }

        if (!removed) {
            owner.method_7353(class_2561.method_43470(target.method_7334().name() + " is not in your team!")
                    .method_27692(class_124.field_1061), false);
            return;
        }

        datManager.get().save();
        owner.method_7353(
                class_2561.method_43470("Removed ")
                        .method_10852(class_2561.method_43470(target.method_7334().name()).method_27692(class_124.field_1061))
                        .method_10852(class_2561.method_43470(" from your team.")),
                false
        );

    }

    public class_5250 getTeamInfo(MinecraftServer server, String teamName) {
        class_2487 teams = datManager.get().getData().method_68568("teams");
        class_2487 teamData = teams.method_68568(teamName);

        if (teamData == null || teamData.method_33133()) {
            return class_2561.method_43470("Team not found!").method_27692(class_124.field_1061);
        }

        class_5250 info = class_2561.method_43470("Team Name: ").method_27692(class_124.field_1065);
        info.method_10852(class_2561.method_43470(teamName).method_27692(class_124.field_1054)).method_10852(class_2561.method_43470("\n"));

        String tag = teamData.method_10558("teamTag").orElse("No Tag");
        info.method_10852(class_2561.method_43470("Team Tag: ").method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(tag).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470("\n"));

        String ownerUUIDStr = teamData.method_10558("owner").orElse("");
        class_3222 ownerPlayer = null;
        try {
            ownerPlayer = server.method_3760().method_14602(UUID.fromString(ownerUUIDStr));
        } catch (IllegalArgumentException ignored) {}
        class_5250 ownerText = (ownerPlayer != null)
                ? class_2561.method_43470(ownerPlayer.method_7334().name()).method_27692(class_124.field_1060)
                : class_2561.method_43470("Offline").method_27692(class_124.field_1061);

        info.method_10852(class_2561.method_43470("Owner: ").method_27692(class_124.field_1065)).method_10852(ownerText).method_10852(class_2561.method_43470("\n"));

        class_2499 members = teamData.method_68569("members");
        int offlineCount = 0;
        class_5250 membersText = class_2561.method_43470("");

        for (int i = 0; i < members.size(); i++) {
            String memberUUIDStr = members.method_10608(i).orElse("");
            class_3222 member = null;
            try {
                member = server.method_3760().method_14602(UUID.fromString(memberUUIDStr));
            } catch (IllegalArgumentException ignored) {}

            if (i > 0) membersText.method_10852(class_2561.method_43470(", "));

            if (member != null) {
                membersText.method_10852(class_2561.method_43470(member.method_7334().name()).method_27692(class_124.field_1060));
            } else {
                offlineCount++;
            }
        }

        if (offlineCount > 0) {
            if (!membersText.getString().isEmpty()) membersText.method_10852(class_2561.method_43470(", "));
            membersText.method_10852(class_2561.method_43470("(" + offlineCount + ") Offline").method_27692(class_124.field_1061));
        }

        info.method_10852(class_2561.method_43470("Members: ").method_27692(class_124.field_1065)).method_10852(membersText);

        return info;
    }

    public static class_2487 createTeam(String teamTag, UUID ownerUUID) {
        class_2487 teamData = new class_2487();

        teamData.method_10582("teamTag", teamTag);
        teamData.method_10582("tagColor", "WHITE");

        teamData.method_10582("owner", ownerUUID.toString());

        teamData.method_10566("members", new class_2499());

        teamData.method_10566("joinRequests", new class_2499());
        teamData.method_10566("invites", new class_2499());

        class_2487 settings = new class_2487();

        settings.method_10556("friendlyFire", false);
        settings.method_10556("highlight", false);
        settings.method_10556("allowRequests", true);
        settings.method_10556("chatUseTag", true);
        settings.method_10556("tabUseTag", true);

        teamData.method_10566("settings", settings);

        return teamData;
    }
}

