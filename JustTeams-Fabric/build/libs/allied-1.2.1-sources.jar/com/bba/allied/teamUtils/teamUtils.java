package com.bba.allied.teamUtils;

import com.bba.allied.data.datManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_2703;
import net.minecraft.class_2995;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;

public class teamUtils {
    static class_2487 data = datManager.get().getData();

    public static final String MOD_ID = "Minecraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static void refreshTabForPlayer(class_3222 player) {
        MinecraftServer server = player.method_51469().method_8503();
        if (server == null) return;

        class_2703 packet = new class_2703(
                class_2703.class_5893.field_29139,
                player
        );
        server.method_3760().method_14581(packet);
    }

    public static void refreshAllTablist(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            class_2703 packet = new class_2703(
                    class_2703.class_5893.field_29139,
                    player
            );
            server.method_3760().method_14581(packet);
        }
    }

    public static void register() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((signedMessage, player, params) -> {
            String rawText = signedMessage.method_46291().getString();
            class_2561 formatted = formatTeamChat(player, rawText);

            UUID uuid = player.method_5667();

            if (teamChatManager.isEnabled(uuid)) {
                String teamName = datManager.get().getTeam(uuid);

                if (teamName != null) {
                    class_2487 teamData = datManager.get().getData()
                            .method_68568("teams")
                            .method_68568(teamName);

                    teamData.method_10558("owner").ifPresent(ownerStr -> {
                        try {
                            class_3222 owner = player.method_51469().method_8503().method_3760()
                                    .method_14602(UUID.fromString(ownerStr));
                            if (owner != null) owner.method_7353(formatted, false);
                        } catch (Exception ignored) {}
                    });

                    var members = teamData.method_68569("members");
                    for (int i = 0; i < members.size(); i++) {
                        members.method_10608(i).ifPresent(memberStr -> {
                            try {
                                class_3222 member = player.method_51469().method_8503().method_3760()
                                        .method_14602(UUID.fromString(memberStr));
                                if (member != null) member.method_7353(formatted, false);
                            } catch (Exception ignored) {}
                        });
                    }
                }
            } else {
                MinecraftServer server = player.method_51469().method_8503();
                if (server != null) {
                    server.method_3760().method_14571().forEach(p -> p.method_7353(formatted, false));
                }
                LOGGER.info("{}", formatted.getString());
            }

            return false;
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> teamUtils.handleFriendlyFire(entity, source));
        ServerTickEvents.END_WORLD_TICK.register(world -> updateHighlight(world.method_8503()));
    }

    private static class_2561 formatTeamChat(class_3222 player, String originalMessage) {
        class_2487 teams = datManager.get().getData().method_68568("teams");
        String playerUuid = player.method_5667().toString();

        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);

            if (team.method_10558("owner").orElse("").equals(playerUuid)) {
                return buildChatMessage(player, originalMessage, team, teamName);
            }

            var members = team.method_68569("members");
            for (int i = 0; i < members.size(); i++) {
                if (members.method_10608(i).orElse("").equals(playerUuid)) {
                    return buildChatMessage(player, originalMessage, team, teamName);
                }
            }
        }
        return class_2561.method_43470("<")
                .method_10852(player.method_5476())
                .method_27693("> ")
                .method_27693(originalMessage).method_27692(class_124.field_1068);
    }

    private static class_2561 buildChatMessage(
            class_3222 player,
            String message,
            class_2487 team,
            String internalTeamName
    ) {
        boolean useTag = team
                .method_68568("settings")
                .method_10577("chatUseTag")
                .orElse(false);

        String colorStr = team
                .method_10558("tagColor")
                .orElse("WHITE");

        class_124 color;
        try {
            color = class_124.valueOf(colorStr.toUpperCase());
        } catch (Exception e) {
            color = class_124.field_1068;
        }

        class_268 scoreboardTeam = player.method_5781();

        class_2561 prefix = class_2561.method_43473();
        class_2561 playerName = class_2561.method_43470(player.method_5477().getString()).method_27692(class_124.field_1068);

        if (scoreboardTeam != null) {
            prefix = scoreboardTeam.method_1144();
        }
        class_2561 teamName = class_2561.method_43470("[").method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470(internalTeamName).method_27692(color))
                .method_10852(class_2561.method_43470("] ")).method_27692(class_124.field_1068);

        prefix = useTag ? prefix : teamName;

        UUID uuid = player.method_5667();
        boolean teamChatEnabled = teamChatManager.isEnabled(uuid);

        if (teamChatEnabled) {
            prefix = class_2561.method_43470("[").method_27692(class_124.field_1068)
                    .method_10852(class_2561.method_43470("TEAM").method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470("] ")).method_27692(class_124.field_1068);
        }

        return class_2561.method_43473()
                .method_10852(prefix)
                .method_10852(class_2561.method_43470("<"))
                .method_10852(playerName)
                .method_10852(class_2561.method_43470("> "))
                .method_10852(class_2561.method_43470(message));
    }

    public static void rebuildTeams(
            MinecraftServer server
    ) {
        removeAllTeams(server);

        class_2487 teamsNBT = data.method_68568("teams");

        for (String internalTeamName : teamsNBT.method_10541()) {
            class_2487 teamData = teamsNBT.method_68568(internalTeamName);
            if (teamData.method_33133()) continue;

            String colorStr = teamData
                    .method_10558("tagColor")
                    .orElse("WHITE");

            class_124 teamColor;
            try {
                teamColor = class_124.valueOf(colorStr.toUpperCase());
            } catch (IllegalArgumentException e) {
                teamColor = class_124.field_1068;
            }

            class_268 scoreboardTeam = addTeam(server, internalTeamName, teamColor);

            teamData.method_10558("owner").ifPresent(ownerUuidStr -> {
                try {
                    UUID uuid = UUID.fromString(ownerUuidStr);
                    class_3222 player = server.method_3760().method_14602(uuid);
                    if (player != null) {
                        addPlayerToTeam(server, player, scoreboardTeam);
                    }
                } catch (IllegalArgumentException ignored) {}
            });

            var members = teamData.method_68569("members");
            for (int i = 0; i < members.size(); i++) {
                members.method_10608(i).ifPresent(memberUuidStr -> {
                    try {
                        UUID uuid = UUID.fromString(memberUuidStr);
                        class_3222 player = server.method_3760().method_14602(uuid);
                        if (player != null) {
                            addPlayerToTeam(server, player, scoreboardTeam);
                        }
                    } catch (IllegalArgumentException ignored) {}
                });
            }
        }

        for (class_3222 player : server.method_3760().method_14571()) {
            updateOverheadName(server, player);
        }

        refreshAllTablist(server);
    }

    public static void updateOverheadName(MinecraftServer server, class_3222 player) {
        class_2487 teams = datManager.get().getData().method_68568("teams");
        String uuid = player.method_5667().toString();

        for (String internalTeamName : teams.method_10541()) {
            class_2487 teamData = teams.method_68568(internalTeamName);

            boolean isOwner = teamData.method_10558("owner").orElse("").equals(uuid);
            boolean isMember = teamData.method_68569("members").stream()
                    .anyMatch(e -> e.method_68658().orElse("").equals(uuid));

            if (isOwner || isMember) {
                String tag = teamData.method_10558("teamTag").orElse(internalTeamName).toUpperCase();
                String colorStr = teamData.method_10558("tagColor").orElse("WHITE");
                class_124 tagColor;

                try {
                    tagColor = class_124.valueOf(colorStr.toUpperCase());
                } catch (IllegalArgumentException e) {
                    tagColor = class_124.field_1068;
                }

                class_2561 prefix = class_2561.method_43470("[")
                        .method_27692(class_124.field_1068)
                        .method_10852(class_2561.method_43470(tag).method_27692(tagColor))
                        .method_10852(class_2561.method_43470("] ").method_27692(class_124.field_1068));

                class_2995 scoreboard = server.method_3845();
                String teamId = toTeamId(internalTeamName);
                class_268 team = scoreboard.method_1153(teamId);
                if (team == null) {
                    team = scoreboard.method_1171(teamId);
                }

                team.method_1138(prefix);
                team.method_1139(class_2561.method_43473());
                team.method_1141(class_124.field_1068);
                scoreboard.method_1172(player.method_5820(), team);
                return;
            }
        }

        class_2995 scoreboard = server.method_3845();
        for (class_268 team : scoreboard.method_1159()) {
            if (team.method_1204().contains(player.method_5820())) {
                scoreboard.method_1157(player.method_5820(), team);
            }
        }
    }

    public static void removeAllTeams(MinecraftServer server) {
        class_2995 scoreboard = server.method_3845();

        for (class_268 team : scoreboard.method_1159().toArray(class_268[]::new)) {
            scoreboard.method_1191(team);
        }
    }

    public static String toTeamId(String name) {
        return name.toLowerCase().replaceAll("\\s+", "");
    }

    public static class_268 addTeam(
            MinecraftServer server,
            String fullName,
            class_124 color
    ) {
        class_2995 scoreboard = server.method_3845();
        String teamId = toTeamId(fullName);

        class_268 team = scoreboard.method_1153(teamId);
        if (team == null) {
            team = scoreboard.method_1171(teamId);
        }

        team.method_1137(class_2561.method_43470(fullName));
        team.method_1141(color);

        return team;
    }

    public static void addPlayerToTeam(
            MinecraftServer server,
            class_3222 player,
            class_268 team
    ) {
        class_2995 scoreboard = server.method_3845();

        scoreboard.method_1172(player.method_5820(), team);
    }

    public static boolean handleFriendlyFire(class_1309 victim, class_1282 source) {
        if (!(source.method_5529() instanceof class_3222 attacker)) {
            return true;
        }

        if (!(victim instanceof class_3222 victimPlayer)) {
            return true;
        }

        class_2487 teams = datManager.get().getData().method_68568("teams");

        String attackerUuid = attacker.method_5667().toString();
        String victimUuid = victimPlayer.method_5667().toString();

        String attackerTeam = findPlayersTeam(teams, attackerUuid);
        String victimTeam   = findPlayersTeam(teams, victimUuid);

        if (attackerTeam == null || !attackerTeam.equals(victimTeam)) {
            return true;
        }

        class_2487 teamData = teams.method_68568(attackerTeam);

        return teamData
                .method_68568("settings")
                .method_10577("friendlyFire")
                .orElse(false);
    }

    private static String findPlayersTeam(class_2487 teams, String uuid) {
        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);

            if (team.method_10558("owner").orElse("").equals(uuid)) {
                return teamName;
            }

            var members = team.method_68569("members");
            for (int i = 0; i < members.size(); i++) {
                if (members.method_10608(i).orElse("").equals(uuid)) {
                    return teamName;
                }
            }
        }
        return null;
    }

    public static void updateHighlight(MinecraftServer server) {
        class_2487 teams = datManager.get().getData().method_68568("teams");

        Map<String, class_2487> uuidToTeam = new HashMap<>();
        for (String teamName : teams.method_10541()) {
            class_2487 team = teams.method_68568(teamName);
            team.method_10558("owner").ifPresent(owner -> uuidToTeam.put(owner, team));

            var members = team.method_68569("members");
            for (int i = 0; i < members.size(); i++) {
                members.method_10608(i).ifPresent(member -> uuidToTeam.put(member, team));
            }
        }

        for (class_3222 player : server.method_3760().method_14571()) {

            class_2487 playerTeam = uuidToTeam.get(player.method_5667().toString());

            boolean highlightEnabled = false;
            if (playerTeam != null) {
                highlightEnabled = playerTeam
                        .method_68568("settings")
                        .method_10577("highlight")
                        .orElse(false);
            }

            for (class_3222 teammate : server.method_3760().method_14571()) {
                if (teammate == player) continue;

                class_2487 teammateTeam = uuidToTeam.get(teammate.method_5667().toString());

                boolean shouldGlow = highlightEnabled
                        && teammateTeam != null
                        && teammateTeam == playerTeam
                        && teammate.method_6059(class_1294.field_5905);

                teammate.method_5834(shouldGlow);
            }
        }
    }
}
